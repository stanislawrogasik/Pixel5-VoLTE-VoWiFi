SKIPMOUNT=false
PROPFILE=true

POSTFSDATA=false

LATESTARTSERVICE=false

  ui_print "************************************"
  ui_print "            Pixel 5 "
  ui_print "      VoLTE & VoWiFi switches "
  ui_print " Suitable for mobile phones with  "
  ui_print "************************************"
set_permissions() {
  # The following is the default rule, DO NOT remove
  set_perm_recursive $MODPATH 0 0 0755 0644

  # Here are some examples:
  # set_perm_recursive  $MODPATH/system/lib       0     0       0755      0644
  # set_perm  $MODPATH/system/bin/app_process32   0     2000    0755      u:object_r:zygote_exec:s0
  # set_perm  $MODPATH/system/bin/dex2oat         0     2000    0755      u:object_r:dex2oat_exec:s0
  # set_perm  $MODPATH/system/lib/libart.so       0     0       0644
}
  
  ui_print "Execution complete!"
